/*
 * AD9910Driver.h
 *
 *  Created on: 13.03.2019
 *      Author: voyag
 */

#ifndef DRIVER_AD9910_AD9910DRIVER_H_
#define DRIVER_AD9910_AD9910DRIVER_H_

class AD9910_Driver {
public:
	AD9910_Driver();
	virtual ~AD9910_Driver();
};

#endif /* DRIVER_AD9910_AD9910DRIVER_H_ */
