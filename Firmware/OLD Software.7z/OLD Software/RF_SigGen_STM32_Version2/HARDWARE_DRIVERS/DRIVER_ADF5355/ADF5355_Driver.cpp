/*
 * ADF5355Driver.cpp
 *
 *  Created on: 13.03.2019
 *      Author: voyag
 */

#include "ADF5355_Driver.h"
 ADF5355_Driver::ADF5355_Driver(){
	// TODO Auto-generated constructor stub

}

ADF5355_Driver::~ADF5355_Driver() {
	// TODO Auto-generated destructor stub
}

bool ADF5355_Driver::Init(){

}
