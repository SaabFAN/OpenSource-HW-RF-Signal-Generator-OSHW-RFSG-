#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2019-03-14 23:15:13

#include "Arduino.h"
#include "Arduino.h"
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <gfxfont.h>
#include <Adafruit_HX8357.h>
#include <Adafruit_STMPE610.h>
#include "HARDWARE_DRIVERS/DRIVER_ANALOGBOARD/ARSGSigPathConfig.h"
#include <Adafruit_ADS1015.h>
#include "HARDWARE_DRIVERS/DRIVER_Attenuator/AttenuatorDriver.h"
#include "HARDWARE_DRIVERS/DRIVER_ADF4351/ADF4351Driver.h"

void SigPathCalibration();
void CalRef();
void UpdateDisplay() ;
void UpdateDisplayPart(int dispPart) ;
void Message(String message, int mcolor) ;
void DisplaySysMode(String message, int mcolor) ;
void ShowSysStatus() ;
void DrawButton (uint16_t XPosButt, uint16_t YPosButt, String ButtText, bool Highlight, uint16_t ButtColor, int TxtSize) ;
void DrawFrequencyArea(unsigned long dispData) ;
void DrawAmplitudeArea(unsigned long dispData) ;
void DrawModulationArea(unsigned long disData1, unsigned long dispData2, unsigned long dispData3, unsigned long dispData4) ;
void DrawSigPathParams() ;
void SetupAD9910(int AD9910_Mode) ;
void SetFreqAD9910(double FreqAD9910) ;
void SetPhaseOffsetAD9910(unsigned long PhaseOffsetAD9910) ;
void SetAmplitudeAD9910(float AmplitudeAD9910, bool Decibels) ;
void SendCFR() ;
void WriteAD9910(byte AD9910_INST) ;
void DAC_Setup() ;
void SetAGC_LVL(int lvl_mv) ;
void SetAGC_BIAS(int bias_mv) ;
int ADC_READ(byte ADC_CHANNEL) ;
void ErrorMode(int emode, bool critical) ;
void ReadGPIO() ;
void ReadKeybd() ;
void ReadKeyboard() ;
void num(signed long n) ;
void TouchInit() ;
void TouchCalibration() ;
void ReadTouch() ;
void CalcPixelPos() ;
void TouchButton() ;
void keypadInit() ;
char get_Key() ;
void pcf8574_write(int addr, int data) ;
int pcf8574_byte_read(int addr) ;
void WriteNVData(int NV_DATA, int NV_ADDR) ;
int ReadNVData(int NV_ADDR) ;
void ReadNVDataBurst(int NV_ADDR, byte burstLength, byte ReadNV_Target) ;
void ReadCalData() ;
void CheckSerial() ;
void ReportStatus() ;
void SetFreq(double FreqSetFreq) ;
void SetFreqFAST(double FreqSetFreq) ;
void Splash() ;
void setup() ;
void loop() ;
void SetAmplitude(float Amplitude) ;
void SetLPF(int LPF_SEL, bool SelectAD9910, bool mixpath) ;
void TestDisplay() ;
void SignalPathTest() ;
void SigPathCompensate() ;
void CheckAttenuator(bool PowerOnTest) ;
void CheckAD9910() ;
void CheckADF4351() ;
void CheckAnalog() ;

#include "SigGen_STM32_Version2.ino"

#include "CALIBRATION_Routines.ino"
#include "DISPLAY_Functions.ino"
#include "DRIVERS.ino"
#include "ERROR_Handlers.ino"
#include "INPUT_Functions.ino"
#include "ISRs.ino"
#include "Keyboard_Routines.ino"
#include "NVRAM.ino"
#include "REMOTE_CONTROL.ino"
#include "SIGNAL_CONTROL.ino"
#include "SPLASHSCREEN.ino"
#include "SigPathConfig.ino"
#include "TEST_Routines.ino"

#endif
