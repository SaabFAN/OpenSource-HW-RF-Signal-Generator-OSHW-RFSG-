/*
 * Interrupts.cpp
 *
 *  Created on: 16.03.2019
 *      Author: voyag
 */

#include "Interrupts.h"

Interrupts::Interrupts() {
	// TODO Auto-generated constructor stub

}

Interrupts::~Interrupts() {
	// TODO Auto-generated destructor stub
}

