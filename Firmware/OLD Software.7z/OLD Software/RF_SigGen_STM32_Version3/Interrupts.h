/*
 * Interrupts.h
 *
 *  Created on: 16.03.2019
 *      Author: voyag
 */

#ifndef INTERRUPTS_H_
#define INTERRUPTS_H_

class Interrupts {
public:
	Interrupts();
	virtual ~Interrupts();
};

#endif /* INTERRUPTS_H_ */
