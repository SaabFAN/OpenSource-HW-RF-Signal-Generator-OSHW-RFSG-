/*
 * AttenuatorDriver.cpp
 *
 *  Created on: 16.03.2019
 *      Author: voyag
 */

#include "AttenuatorDriver.h"

AttenuatorDriver::AttenuatorDriver() {
	// TODO Auto-generated constructor stub

}

AttenuatorDriver::~AttenuatorDriver() {
	// TODO Auto-generated destructor stub
}

