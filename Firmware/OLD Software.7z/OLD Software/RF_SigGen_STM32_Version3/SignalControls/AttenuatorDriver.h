/*
 * AttenuatorDriver.h
 *
 *  Created on: 16.03.2019
 *      Author: voyag
 */

#ifndef ATTENUATORDRIVER_H_
#define ATTENUATORDRIVER_H_

class AttenuatorDriver {
public:
	AttenuatorDriver();
	virtual ~AttenuatorDriver();
};

#endif /* ATTENUATORDRIVER_H_ */
