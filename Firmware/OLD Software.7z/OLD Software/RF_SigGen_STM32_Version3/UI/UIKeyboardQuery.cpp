/*
 * UIKeyboardQuery.cpp
 *
 *  Created on: 15.03.2019
 *      Author: voyag
 */

#include "UIKeyboardQuery.h"

UI_KeyboardQuery::UI_KeyboardQuery() {
	// TODO Auto-generated constructor stub

}

UI_KeyboardQuery::~UI_KeyboardQuery() {
	// TODO Auto-generated destructor stub
}

